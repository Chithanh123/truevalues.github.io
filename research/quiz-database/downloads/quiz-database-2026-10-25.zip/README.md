# Political Context: quiz packages and intended outcomes

Start with [the readable overview](generated/package-overview.md). No database application is needed for this document.

Open [quiz-packages.sqlite3](generated/quiz-packages.sqlite3) in a SQLite 3.37+ browser, or use the files in generated/csv/ in a spreadsheet. The most useful sheets are package_summary.csv and package_outcome_matrix.csv.

Five package records, 91 authored items, 31 provisional intended outcomes. The current quiz has 49 tasks; review packets A/B/C each have 14 tasks; FUTURE-24 has no selected questions. CR-S03 is a comprehension probe, and missing Vietnamese drafts are marked.

This is an author catalog with no participant answers. Intended outcomes are not desired political answers or validated diagnoses. The database contains country-inspiration spoilers in a separate world_reveals table; the participant quiz keeps the end-only reveal.

queries.sql contains eight example SELECT queries. All 12 catalog checks pass. source-manifest.json identifies the source snapshot; rebuilding requires the authored repository sources and tools in research/quiz-database/. Editing this download does not update those sources.

Repository: https://github.com/Chithanh123/truevalues.github.io/tree/research/ideological-foundations/research/quiz-database
